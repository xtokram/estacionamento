-- INSERT INTO consultorio.convenios (id, atualizado, cadastro, excluido, nome, valor) VALUES (1, NULL, '2022-04-07 19:52:54.824299', NULL, 'Itamed', 257.320);
-- INSERT INTO consultorio.convenios (id, atualizado, cadastro, excluido, nome, valor) VALUES (2, NULL, '2022-04-07 19:53:05.636569', NULL, 'Unimed', 227.320);
-- INSERT INTO consultorio.convenios (id, atualizado, cadastro, excluido, nome, valor) VALUES (3, NULL, '2022-04-07 19:53:48.402342', NULL, 'Amil', 243.090);
-- INSERT INTO consultorio.convenios (id, atualizado, cadastro, excluido, nome, valor) VALUES (4, NULL, '2022-04-07 19:54:16.459674', NULL, 'MiltVida', 290.780);

-- SELECT pg_catalog.setval('public.hibernate_sequence', 5, true);