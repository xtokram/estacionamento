package br.com.uniamerica.consultorioapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsultorioApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
